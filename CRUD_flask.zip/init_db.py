#executar no shell: python init_db.py
import sqlite3


def init_db():
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT NOT NULL
            )
        ''')
        conn.commit()
        conn.close()
        print("Database and table created successfully")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == '__main__':
    init_db()
